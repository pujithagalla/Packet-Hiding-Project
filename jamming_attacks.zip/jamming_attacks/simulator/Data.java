package simulator;


public class Data {
    String content;

    public Data(String content) {
        this.content = content;
    }

    public Data() {
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}

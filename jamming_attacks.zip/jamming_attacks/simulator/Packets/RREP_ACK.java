package simulator.Packets;

import simulator.Node;


public class RREP_ACK extends Packet{
    public RREP_ACK() {
        this.type = 4;
    }

    public void recieve(Node reciever, Node prev_hop) {
        
    }
}

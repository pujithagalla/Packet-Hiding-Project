package UI.utitlity;

import UI.myobjects.GraphicalNode;

public class GNodeWrapper implements Comparable{
    double distace;
    GraphicalNode gnode;

    public GNodeWrapper(double distace, GraphicalNode gnode) {
        this.distace = distace;
        this.gnode = gnode;
    }

    public double getDistace() {
        return distace;
    }

    public GraphicalNode getGnode() {
        return gnode;
    }

    public int compareTo(Object o) {
        return Double.compare(this.distace,((GNodeWrapper)o).getDistace());
    }
}


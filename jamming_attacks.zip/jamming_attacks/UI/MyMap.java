package UI;

import javax.swing.*;
import java.awt.*;


public class MyMap extends JPanel {
}

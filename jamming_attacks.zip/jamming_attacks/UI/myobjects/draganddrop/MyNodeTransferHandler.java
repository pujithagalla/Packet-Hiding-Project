package UI.myobjects.draganddrop;

import logger.MyLogger;

import javax.swing.*;
import java.awt.datatransfer.Transferable;

import UI.myobjects.NodeButton;
import UI.myobjects.GraphicalNode;


public class MyNodeTransferHandler  extends TransferHandler  {
    protected Transferable createTransferable(JComponent c) {
        GraphicalNode source = (GraphicalNode)c;
        MyLogger.logger.debug("NodeButton createTranserable");
        source.setShouldRemoved(true);
        return source;
    }

    public int getSourceActions(JComponent c) {
        return COPY_OR_MOVE;
    }
    protected void exportDone(JComponent c, Transferable data, int action) {
//            if (shouldRemove && (action == MOVE)) {
//                sourcePic.setImage(null);
//            }
//            sourcePic = null;
    }
}

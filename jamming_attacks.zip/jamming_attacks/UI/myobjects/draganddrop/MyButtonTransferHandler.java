package UI.myobjects.draganddrop;

import logger.MyLogger;

import javax.swing.*;
import java.awt.datatransfer.Transferable;

import UI.myobjects.NodeButton;
import UI.myobjects.GraphicalNode;
import UI.actions.NodePropOKBtnAction;


public class MyButtonTransferHandler extends TransferHandler {


    protected Transferable createTransferable(JComponent c) {
        NodeButton source = (NodeButton)c;
        MyLogger.logger.debug("NodeButton createTranserable");
        GraphicalNode nodeTransferable = new GraphicalNode(source.getIcon(),source.myForm,false);
        source.myForm.putGNode(nodeTransferable);
        nodeTransferable.setTransferHandler(new MyNodeTransferHandler());
        return nodeTransferable;
    }

    public int getSourceActions(JComponent c) {
        return COPY_OR_MOVE;
    }

}

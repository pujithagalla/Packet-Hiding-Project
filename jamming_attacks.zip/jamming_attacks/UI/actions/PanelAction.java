package UI.actions;

import UI.Myform;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class PanelAction extends MouseAdapter {
    Myform myForm;

    public PanelAction(Myform myForm) {
        this.myForm = myForm;
    }
    public void mouseClicked(MouseEvent e) {
        myForm.setSelectedGNode(null);
        myForm.getNodePanel().resetNodePanel();
    }
}

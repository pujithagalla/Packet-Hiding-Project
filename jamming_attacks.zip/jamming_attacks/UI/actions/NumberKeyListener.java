package UI.actions;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;


public class NumberKeyListener extends KeyAdapter {


    public void keyTyped(KeyEvent e) {
        if (e.getKeyChar()<48 || e.getKeyChar()>58){
            e.consume();
           // e.setKeyCode(0);
        }
    }
}

package UI.actions;

import UI.Myform;
import UI.myobjects.GraphicalNode;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class NodePropResetBtnAction implements ActionListener {
    Myform myForm;

    public NodePropResetBtnAction(Myform myForm) {
        this.myForm = myForm;
    }

    public void actionPerformed(ActionEvent e) {
        if (myForm.getSelectedGNode()!=null){
            myForm.getSelectedGNode().fillNodePanel();
        }else{
            myForm.getNodePanel().resetNodePropertiest();
        }
    }
}

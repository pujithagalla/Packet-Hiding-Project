package test;


public class TestFlag {
    public String s = "";
}
